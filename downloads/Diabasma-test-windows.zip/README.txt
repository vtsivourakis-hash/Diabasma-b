DIABASMA - WINDOWS TEST APP

Extract all files, then double-click Start-Diabasma.cmd.
Uses installed Edge or Chrome in an app window. No installer or server.
Bundled lessons work offline; external textbooks need internet.
Progress stays in this browser profile and does not sync with the website.
Keep the same folder for progress. Download again for new content.
If app mode is unavailable, open Diabasma.html directly.
